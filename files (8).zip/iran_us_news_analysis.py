"""
Iran-US news dataset: cleaning + EDA (pandas)
Input : iran_us_news_dataset.csv  (columns: link, title, content, date, _source, _keyword)
Output: clean_news.csv, eda_*.csv in ./analysis_output/

Run:  python iran_us_news_analysis.py [path_to_csv]
"""
import re
import sys
import os
import pandas as pd

CSV = sys.argv[1] if len(sys.argv) > 1 else "iran_us_news_dataset.csv"
OUT = "analysis_output"
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- 1. LOAD
raw = pd.read_csv(CSV)
print("Raw shape:", raw.shape)
print(raw.dtypes)
print("Nulls:\n", raw.isna().sum())

# ---------------------------------------------------------------- 2. CLEAN
df = raw.copy()
for c in ["link", "title", "content", "_source", "_keyword"]:
    df[c] = df[c].astype("string").str.strip()

# Collection channel is encoded as a prefix of _source ("Bing-", "RSS-") or is the plain 'BBC' scrape.
df["channel"] = df["_source"].str.extract(r"^(Bing|RSS)-")[0].fillna("BBC scrape")
df["source_clean"] = df["_source"].str.replace(r"^(Bing|RSS)-", "", regex=True).str.strip()

# Only merge source labels that are clearly the same outlet.
SOURCE_MAP = {
    "BBC Middle East": "BBC", "BBC World": "BBC",
    "Al Jazeera English": "Al Jazeera",
    "dw": "DW",
    "moneycontrol.com": "Moneycontrol",
    "Tempo.co English": "Tempo", "Tempo": "Tempo",
    "Associated Press News": "Associated Press",
    "CNN International": "CNN",
    "Mehr News Agency": "Mehr News", "en.mehrnews": "Mehr News",
    "AOL.co.uk": "AOL",
    "rediff.com": "Rediff Money",
    "Anadolu Ajansi": "Anadolu Agency",
    "The Week": "The Week", "THE WEEK": "The Week",
    "Al Bawaba News": "Al Bawaba",
    "Janes": "Jane's Information Group",
    "Berita Satu": "Berita",
}
df["source_clean"] = df["source_clean"].replace(SOURCE_MAP)

# Dates: ISO strings. Date-only values (T00:00:00 or 10 chars) have no time-of-day information.
df["date_parsed"] = pd.to_datetime(df["date"], format="ISO8601", errors="coerce")  # handles both date-only and datetime strings
df["has_date"] = df["date_parsed"].notna()
df["pub_date"] = df["date_parsed"].dt.normalize()
df["pub_month"] = df["date_parsed"].dt.to_period("M").astype("string")

# Missing dates are NOT imputed (67% missing; mostly the BBC scrape). They are excluded from time trends only.

df["content_length"] = df["content"].str.len()
df["word_count"] = df["content"].str.split().str.len()
df["short_content_flag"] = df["content_length"] < 300          # likely video/teaser page, not a full article
df["very_long_flag"] = df["content_length"] > 32767            # exceeds Excel cell limit

# Duplicates: same title seen in multiple rows (syndication / BBC + RSS-BBC). Rows kept, repeats flagged.
df["title_key"] = df["title"].str.lower().str.replace(r"\s+", " ", regex=True)
df["dup_title_repeat"] = df.duplicated("title_key", keep="first")
df["content_key"] = df["content"].str.lower().str.replace(r"\s+", " ", regex=True)
df["dup_content_repeat"] = df.duplicated("content_key", keep="first")

# Rule-based theme flags on title + content (documented keyword lists; a row can have several themes).
THEMES = {
    "Hormuz / Oil & Energy": r"hormuz|oil|crude|brent|tanker|energy|blockade",
    "Nuclear Programme": r"nuclear|enrich|fordow|natanz|isfahan|uranium|iaea",
    "Ceasefire / Peace Talks": r"ceasefire|cease-fire|peace deal|peace talks|negotiat|truce|memorandum|interim (?:deal|agreement)",
    "Sanctions / Frozen Assets": r"sanction|frozen asset|frozen fund|frozen overseas",
    "Leadership / Khamenei": r"khamenei|supreme leader|araghchi|pezeshkian|ayatollah",
    "Israel & Lebanon": r"israel|lebanon|hezbollah|idf|gaza",
    "Markets / Crypto": r"bitcoin|crypto|stock market|markets|investor|oil price",
    "Military Strikes": r"strike|missile|drone|bomb|airstrike|midnight hammer|attack",
}
text = (df["title"].fillna("") + " " + df["content"].fillna("")).str.lower()
for name, pat in THEMES.items():
    df["theme_" + re.sub(r"\W+", "_", name.lower()).strip("_")] = text.str.contains(pat, regex=True).astype(int)

# ---------------------------------------------------------------- 3. EDA
clean_summary = {
    "rows_raw": len(raw), "rows_clean": len(df),
    "missing_date": int((~df.has_date).sum()),
    "dup_title_repeats": int(df.dup_title_repeat.sum()),
    "dup_content_repeats": int(df.dup_content_repeat.sum()),
    "short_content": int(df.short_content_flag.sum()),
    "over_excel_cell_limit": int(df.very_long_flag.sum()),
    "unique_sources_raw": int(raw["_source"].nunique()),
    "unique_sources_clean": int(df.source_clean.nunique()),
    "date_min": df.pub_date.min(), "date_max": df.pub_date.max(),
}
print(pd.Series(clean_summary))

unique_articles = df[~df.dup_title_repeat]        # KPI population: first occurrence of each title

by_source = unique_articles.groupby("source_clean").size().sort_values(ascending=False).rename("articles")
by_keyword = unique_articles.groupby("_keyword").size().sort_values(ascending=False).rename("articles")
by_channel = unique_articles.groupby("channel").size().rename("articles")
by_month = unique_articles[unique_articles.has_date].groupby("pub_month").size().rename("articles")
daily = unique_articles[unique_articles.has_date].groupby("pub_date").size().rename("articles")
theme_cols = [c for c in df.columns if c.startswith("theme_")]
theme_counts = unique_articles[theme_cols].sum().sort_values(ascending=False).rename("articles")
length_stats = unique_articles["content_length"].describe()

print(by_source.head(10), by_keyword, by_channel, by_month, theme_counts, length_stats, sep="\n\n")

# Concentration: share of articles from the top 5 sources
top5_share = by_source.head(5).sum() / by_source.sum()
print(f"Top-5 source share: {top5_share:.1%}")

# Daily spikes: days > mean + 2*std (dated articles only)
thr = daily.mean() + 2 * daily.std()
spikes = daily[daily > thr]
print("Spike threshold:", round(thr, 1)); print(spikes)

# ---------------------------------------------------------------- 4. EXPORT
df.drop(columns=["title_key", "content_key", "date_parsed"]).to_csv(f"{OUT}/clean_news.csv", index=False)
for name, s in {"by_source": by_source, "by_keyword": by_keyword, "by_channel": by_channel,
                "by_month": by_month, "daily": daily, "themes": theme_counts}.items():
    s.to_csv(f"{OUT}/eda_{name}.csv")
pd.Series(clean_summary).to_csv(f"{OUT}/cleaning_summary.csv", header=["value"])
print("Saved to", OUT)
