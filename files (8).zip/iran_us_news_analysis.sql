/* ======================================================================
   IRAN-US NEWS DATASET : CLEANING, VALIDATION AND ANALYSIS
   ----------------------------------------------------------------------
   Dialect        : PostgreSQL 13+ (uses regexp_replace, ~*, FILTER, date_trunc)
   Staging table  : stg_iran_us_news  (load iran_us_news_dataset.csv into it first)
                    e.g.  \copy stg_iran_us_news FROM 'iran_us_news_dataset.csv' CSV HEADER
   Source columns : link, title, content, date, _source, _keyword  (all loaded as TEXT)
   Objects        : creates 1 staging table and 2 views (v_news_clean, v_news_unique).
                    No data is deleted or updated. Everything else is read-only SELECTs.
   Cleaning logic mirrors iran_us_news_analysis.py and the Excel workbook:
     * whitespace trimmed; channel = Bing / RSS / BBC scrape (from _source prefix)
     * source_clean = _source without prefix, with a small map of clearly identical outlets
     * missing dates are NOT imputed; they are excluded from time trends only
     * duplicates (same lower-cased title) are flagged, not deleted
     * KPI population = "unique articles" = first occurrence of each title
   Note: "first occurrence" is decided by CSV row order, so the staging table needs a row_id
         column that preserves file order (added below with GENERATED ALWAYS AS IDENTITY).
   ====================================================================== */


/* ---------------------------------------------------------------------
   1. STAGING TABLE
   --------------------------------------------------------------------- */
CREATE TABLE IF NOT EXISTS stg_iran_us_news (
    row_id    INT GENERATED ALWAYS AS IDENTITY,
    link      TEXT,
    title     TEXT,
    content   TEXT,
    date      TEXT,       -- ISO strings: 'YYYY-MM-DDTHH:MI:SS' or 'YYYY-MM-DD'; NULL when missing
    _source   TEXT,
    _keyword  TEXT
);
-- For \copy, name the columns so row_id is auto-filled:
-- \copy stg_iran_us_news(link,title,content,date,_source,_keyword) FROM 'iran_us_news_dataset.csv' CSV HEADER


/* ---------------------------------------------------------------------
   2. SCHEMA AND DATA PROFILING
   --------------------------------------------------------------------- */
SELECT COUNT(*)                                   AS total_rows,
       COUNT(DISTINCT link)                       AS distinct_links,
       COUNT(DISTINCT title)                      AS distinct_titles,
       COUNT(DISTINCT _source)                    AS distinct_raw_sources,
       COUNT(DISTINCT _keyword)                   AS distinct_keywords,
       COUNT(*) FILTER (WHERE date IS NULL OR btrim(date) = '') AS missing_dates,
       MIN(date) AS min_date_text, MAX(date) AS max_date_text
FROM stg_iran_us_news;

SELECT _keyword, COUNT(*) AS rows_loaded
FROM stg_iran_us_news GROUP BY _keyword ORDER BY rows_loaded DESC;


/* ---------------------------------------------------------------------
   3. CLEAN ANALYTICAL VIEW  (flags rather than deletes)
   --------------------------------------------------------------------- */
CREATE OR REPLACE VIEW v_news_clean AS
WITH base AS (
    SELECT
        row_id,
        btrim(link)     AS link,
        btrim(title)    AS title,
        btrim(content)  AS content,
        NULLIF(btrim(date), '')::timestamp AS published_ts,   -- ISO strings cast safely in PostgreSQL
        btrim(_source)  AS source_raw,
        btrim(_keyword) AS keyword,
        COALESCE((regexp_match(btrim(_source), '^(Bing|RSS)-'))[1], 'BBC scrape') AS channel,
        btrim(regexp_replace(btrim(_source), '^(Bing|RSS)-', '')) AS source_stripped
    FROM stg_iran_us_news
),
mapped AS (
    SELECT b.*,
           CASE b.source_stripped
               WHEN 'BBC Middle East'   THEN 'BBC'
               WHEN 'BBC World'         THEN 'BBC'
               WHEN 'Al Jazeera English' THEN 'Al Jazeera'
               WHEN 'dw'                THEN 'DW'
               WHEN 'moneycontrol.com'  THEN 'Moneycontrol'
               WHEN 'Tempo.co English'  THEN 'Tempo'
               WHEN 'The Hindu BusinessLine' THEN 'The Hindu'
               WHEN 'Business Line'     THEN 'The Hindu'     -- link domain = thehindubusinessline.com
               WHEN 'Associated Press News' THEN 'Associated Press'
               WHEN 'CNN International' THEN 'CNN'
               WHEN 'Mehr News Agency'  THEN 'Mehr News'
               WHEN 'en.mehrnews'       THEN 'Mehr News'
               WHEN 'AOL.co.uk'         THEN 'AOL'
               WHEN 'rediff.com'        THEN 'Rediff Money'
               WHEN 'Anadolu Ajansi'    THEN 'Anadolu Agency'
               WHEN 'THE WEEK'          THEN 'The Week'
               WHEN 'Al Bawaba News'    THEN 'Al Bawaba'
               WHEN 'Janes'             THEN 'Jane''s Information Group'
               WHEN 'Berita Satu'       THEN 'Berita'
               ELSE b.source_stripped
           END AS source_clean
    FROM base b
),
flagged AS (
    SELECT m.*,
           date_trunc('day',   m.published_ts)::date  AS pub_date,
           to_char(m.published_ts, 'YYYY-MM')         AS pub_month,
           (m.published_ts IS NOT NULL)               AS has_date,
           length(m.content)                          AS content_length,
           array_length(regexp_split_to_array(btrim(m.content), '\s+'), 1) AS word_count,
           (length(m.content) < 300)                  AS short_content_flag,
           (length(m.content) > 32767)                AS very_long_flag,
           (ROW_NUMBER() OVER (PARTITION BY lower(regexp_replace(m.title,   '\s+', ' ', 'g')) ORDER BY m.row_id) > 1) AS dup_title_repeat,
           (ROW_NUMBER() OVER (PARTITION BY lower(regexp_replace(m.content, '\s+', ' ', 'g')) ORDER BY m.row_id) > 1) AS dup_content_repeat,
           lower(coalesce(m.title,'') || ' ' || coalesce(m.content,'')) AS txt
    FROM mapped m
)
SELECT f.*,
       (txt ~ 'hormuz|oil|crude|brent|tanker|energy|blockade')::int                                             AS theme_hormuz_oil_energy,
       (txt ~ 'nuclear|enrich|fordow|natanz|isfahan|uranium|iaea')::int                                         AS theme_nuclear_programme,
       (txt ~ 'ceasefire|cease-fire|peace deal|peace talks|negotiat|truce|memorandum|interim (deal|agreement)')::int AS theme_ceasefire_peace_talks,
       (txt ~ 'sanction|frozen asset|frozen fund|frozen overseas')::int                                         AS theme_sanctions_frozen_assets,
       (txt ~ 'khamenei|supreme leader|araghchi|pezeshkian|ayatollah')::int                                     AS theme_leadership_khamenei,
       (txt ~ 'israel|lebanon|hezbollah|idf|gaza')::int                                                         AS theme_israel_lebanon,
       (txt ~ 'bitcoin|crypto|stock market|markets|investor|oil price')::int                                    AS theme_markets_crypto,
       (txt ~ 'strike|missile|drone|bomb|airstrike|midnight hammer|attack')::int                                AS theme_military_strikes
FROM flagged f;

-- KPI population: first occurrence of each title
CREATE OR REPLACE VIEW v_news_unique AS
SELECT * FROM v_news_clean WHERE NOT dup_title_repeat;


/* ---------------------------------------------------------------------
   4. DATA-QUALITY VALIDATION  (PASS / WARN / FAIL)
   --------------------------------------------------------------------- */
WITH checks AS (
    SELECT 'row_count_matches_staging' AS check_name, 'reconciliation' AS check_type,
           (SELECT COUNT(*) FROM v_news_clean)::numeric AS actual_value,
           'equals staging row count' AS expected_condition,
           CASE WHEN (SELECT COUNT(*) FROM v_news_clean) = (SELECT COUNT(*) FROM stg_iran_us_news) THEN 'PASS' ELSE 'FAIL' END AS status,
           'high' AS severity
    UNION ALL
    SELECT 'null_or_blank_title', 'completeness', COUNT(*),
           'zero', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END, 'high'
    FROM v_news_clean WHERE title IS NULL OR title = ''
    UNION ALL
    SELECT 'null_or_blank_content', 'completeness', COUNT(*),
           'zero', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END, 'high'
    FROM v_news_clean WHERE content IS NULL OR content = ''
    UNION ALL
    SELECT 'duplicate_links', 'uniqueness', COUNT(*) - COUNT(DISTINCT link),
           'zero (link is a candidate key)', CASE WHEN COUNT(*) = COUNT(DISTINCT link) THEN 'PASS' ELSE 'FAIL' END, 'high'
    FROM v_news_clean
    UNION ALL
    SELECT 'missing_publish_date', 'completeness', COUNT(*),
           'informational: share of rows without date', 
           CASE WHEN COUNT(*) = 0 THEN 'PASS' WHEN COUNT(*) < 0.10*(SELECT COUNT(*) FROM v_news_clean) THEN 'WARN' ELSE 'FAIL' END, 'medium'
    FROM v_news_clean WHERE NOT has_date
    UNION ALL
    SELECT 'dates_in_future', 'validity', COUNT(*),
           'zero (no dates after today)', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END, 'medium'
    FROM v_news_clean WHERE published_ts > now()
    UNION ALL
    SELECT 'repeated_titles', 'uniqueness', COUNT(*),
           'flagged, kept in data', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'WARN' END, 'low'
    FROM v_news_clean WHERE dup_title_repeat
    UNION ALL
    SELECT 'repeated_content', 'uniqueness', COUNT(*),
           'flagged, kept in data', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'WARN' END, 'low'
    FROM v_news_clean WHERE dup_content_repeat
    UNION ALL
    SELECT 'short_content_under_300_chars', 'validity', COUNT(*),
           'flagged (video/teaser pages)', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'WARN' END, 'low'
    FROM v_news_clean WHERE short_content_flag
    UNION ALL
    SELECT 'content_over_excel_cell_limit', 'validity', COUNT(*),
           'informational for Excel export', CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'WARN' END, 'low'
    FROM v_news_clean WHERE very_long_flag
    UNION ALL
    SELECT 'source_labels_merged', 'consistency', 
           (SELECT COUNT(DISTINCT source_raw) FROM v_news_clean) - (SELECT COUNT(DISTINCT source_clean) FROM v_news_clean),
           'informational: raw minus clean distinct labels', 'WARN', 'low'
)
SELECT * FROM checks ORDER BY CASE severity WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, check_name;


/* ---------------------------------------------------------------------
   5. KPI AND BUSINESS ANALYSIS  (unique articles)
   --------------------------------------------------------------------- */
-- 5.1 Headline KPIs
SELECT COUNT(*)                                             AS unique_articles,
       COUNT(DISTINCT source_clean)                         AS distinct_sources,
       ROUND(100.0 * COUNT(*) FILTER (WHERE has_date) / NULLIF(COUNT(*),0), 1) AS pct_with_date,
       ROUND(AVG(content_length)::numeric, 0)               AS avg_content_chars,
       percentile_cont(0.5) WITHIN GROUP (ORDER BY content_length) AS median_content_chars
FROM v_news_unique;

-- 5.2 Channel mix
SELECT channel, COUNT(*) AS articles,
       ROUND(100.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER (),0), 1) AS pct
FROM v_news_unique GROUP BY channel ORDER BY articles DESC;

-- 5.3 Top 15 sources with share and cumulative share
SELECT source_clean, articles,
       ROUND(100.0 * articles / NULLIF(SUM(articles) OVER (),0), 1)                     AS pct,
       ROUND(100.0 * SUM(articles) OVER (ORDER BY articles DESC, source_clean) / NULLIF(SUM(articles) OVER (),0), 1) AS cumulative_pct,
       RANK() OVER (ORDER BY articles DESC) AS rnk
FROM (SELECT source_clean, COUNT(*) AS articles FROM v_news_unique GROUP BY source_clean) s
ORDER BY articles DESC, source_clean
LIMIT 15;

-- 5.4 Sources appearing exactly once (long tail)
SELECT COUNT(*) AS single_article_sources
FROM (SELECT source_clean FROM v_news_unique GROUP BY source_clean HAVING COUNT(*) = 1) t;

-- 5.5 Search keyword volume
SELECT keyword, COUNT(*) AS articles,
       ROUND(100.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER (),0), 1) AS pct
FROM v_news_unique GROUP BY keyword ORDER BY articles DESC;

-- 5.6 Themes (rule-based; overlap allowed)
SELECT theme, articles, ROUND(100.0 * articles / NULLIF((SELECT COUNT(*) FROM v_news_unique),0), 1) AS pct_of_unique
FROM (
    SELECT 'Hormuz / Oil & Energy' AS theme, SUM(theme_hormuz_oil_energy)       AS articles FROM v_news_unique UNION ALL
    SELECT 'Nuclear Programme',               SUM(theme_nuclear_programme)       FROM v_news_unique UNION ALL
    SELECT 'Ceasefire / Peace Talks',         SUM(theme_ceasefire_peace_talks)   FROM v_news_unique UNION ALL
    SELECT 'Sanctions / Frozen Assets',       SUM(theme_sanctions_frozen_assets) FROM v_news_unique UNION ALL
    SELECT 'Leadership / Khamenei',           SUM(theme_leadership_khamenei)     FROM v_news_unique UNION ALL
    SELECT 'Israel & Lebanon',                SUM(theme_israel_lebanon)          FROM v_news_unique UNION ALL
    SELECT 'Markets / Crypto',                SUM(theme_markets_crypto)          FROM v_news_unique UNION ALL
    SELECT 'Military Strikes',                SUM(theme_military_strikes)        FROM v_news_unique
) t ORDER BY articles DESC;

-- 5.7 Content-length distribution
SELECT CASE WHEN content_length < 300   THEN '1. < 300'
            WHEN content_length < 1000  THEN '2. 300-999'
            WHEN content_length < 3000  THEN '3. 1,000-2,999'
            WHEN content_length < 10000 THEN '4. 3,000-9,999'
            ELSE '5. 10,000+' END AS length_bucket,
       COUNT(*) AS articles
FROM v_news_unique GROUP BY 1 ORDER BY 1;


/* ---------------------------------------------------------------------
   6. TIME ANALYSIS  (dated articles only; undated rows are excluded, not imputed)
   --------------------------------------------------------------------- */
-- 6.1 Monthly volume with month-over-month change (only adjacent calendar months compared)
WITH m AS (
    SELECT pub_month, COUNT(*) AS articles
    FROM v_news_unique WHERE has_date GROUP BY pub_month
)
SELECT pub_month, articles,
       LAG(articles) OVER (ORDER BY pub_month) AS prev_dated_month_articles,
       ROUND(100.0 * (articles - LAG(articles) OVER (ORDER BY pub_month))
             / NULLIF(LAG(articles) OVER (ORDER BY pub_month), 0), 1) AS pct_change_vs_prev_listed_month
FROM m ORDER BY pub_month;
-- Caution: months with zero articles are absent, so "previous listed month" may not be the previous calendar month.

-- 6.2 Daily spikes: days above mean + 2 standard deviations (statistical rule)
WITH daily AS (
    SELECT pub_date, COUNT(*) AS articles FROM v_news_unique WHERE has_date GROUP BY pub_date
), stats AS (
    SELECT AVG(articles) AS mu, STDDEV_SAMP(articles) AS sd FROM daily
)
SELECT d.pub_date, d.articles, ROUND(s.mu + 2*s.sd, 1) AS spike_threshold
FROM daily d CROSS JOIN stats s
WHERE d.articles > s.mu + 2*s.sd
ORDER BY d.pub_date;

-- 6.3 Share of dated articles in the final three days of the window
WITH r AS (SELECT MAX(pub_date) AS last_day FROM v_news_unique WHERE has_date)
SELECT COUNT(*) FILTER (WHERE u.pub_date >= r.last_day - 2) AS last_3_days,
       COUNT(*)                                             AS dated_total,
       ROUND(100.0 * COUNT(*) FILTER (WHERE u.pub_date >= r.last_day - 2) / NULLIF(COUNT(*),0), 1) AS pct
FROM v_news_unique u CROSS JOIN r WHERE u.has_date;

-- 6.4 Date coverage by channel (why trends are partial)
SELECT channel, COUNT(*) AS articles,
       COUNT(*) FILTER (WHERE has_date) AS with_date,
       ROUND(100.0 * COUNT(*) FILTER (WHERE has_date) / NULLIF(COUNT(*),0), 1) AS pct_with_date
FROM v_news_unique GROUP BY channel ORDER BY articles DESC;


/* ---------------------------------------------------------------------
   7. ADVANCED: theme by source group (BBC vs all others)
   --------------------------------------------------------------------- */
SELECT CASE WHEN source_clean = 'BBC' THEN 'BBC' ELSE 'All other sources' END AS source_group,
       COUNT(*) AS articles,
       ROUND(100.0 * AVG(theme_hormuz_oil_energy), 1)       AS pct_hormuz_oil,
       ROUND(100.0 * AVG(theme_nuclear_programme), 1)       AS pct_nuclear,
       ROUND(100.0 * AVG(theme_ceasefire_peace_talks), 1)   AS pct_ceasefire,
       ROUND(100.0 * AVG(theme_markets_crypto), 1)          AS pct_markets
FROM v_news_unique GROUP BY 1 ORDER BY articles DESC;


/* ---------------------------------------------------------------------
   8. FINAL QC / RECONCILIATION  (clean layer vs staging)
   --------------------------------------------------------------------- */
SELECT 'row_count' AS metric,
       (SELECT COUNT(*) FROM stg_iran_us_news) AS staging_value,
       (SELECT COUNT(*) FROM v_news_clean)     AS clean_value,
       CASE WHEN (SELECT COUNT(*) FROM stg_iran_us_news) = (SELECT COUNT(*) FROM v_news_clean) THEN 'PASS' ELSE 'FAIL' END AS status
UNION ALL
SELECT 'distinct_links', (SELECT COUNT(DISTINCT link) FROM stg_iran_us_news), (SELECT COUNT(DISTINCT link) FROM v_news_clean),
       CASE WHEN (SELECT COUNT(DISTINCT btrim(link)) FROM stg_iran_us_news) = (SELECT COUNT(DISTINCT link) FROM v_news_clean) THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT 'rows_with_date', (SELECT COUNT(*) FROM stg_iran_us_news WHERE NULLIF(btrim(date),'') IS NOT NULL),
       (SELECT COUNT(*) FROM v_news_clean WHERE has_date),
       CASE WHEN (SELECT COUNT(*) FROM stg_iran_us_news WHERE NULLIF(btrim(date),'') IS NOT NULL) = (SELECT COUNT(*) FROM v_news_clean WHERE has_date) THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT 'unique_plus_repeat_titles = total',
       (SELECT COUNT(*) FROM stg_iran_us_news),
       (SELECT COUNT(*) FROM v_news_unique) + (SELECT COUNT(*) FROM v_news_clean WHERE dup_title_repeat),
       CASE WHEN (SELECT COUNT(*) FROM stg_iran_us_news) = (SELECT COUNT(*) FROM v_news_unique) + (SELECT COUNT(*) FROM v_news_clean WHERE dup_title_repeat) THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT 'sum_of_channel_counts = unique_articles',
       (SELECT COUNT(*) FROM v_news_unique),
       (SELECT SUM(c) FROM (SELECT COUNT(*) AS c FROM v_news_unique GROUP BY channel) x),
       CASE WHEN (SELECT COUNT(*) FROM v_news_unique) = (SELECT SUM(c) FROM (SELECT COUNT(*) AS c FROM v_news_unique GROUP BY channel) x) THEN 'PASS' ELSE 'FAIL' END;

-- Expected values for the supplied file (from the pandas run and the Excel workbook):
--   rows 2,286 | unique articles 2,194 | repeated titles 92 | repeated content 41 | missing dates 1,534
--   dated range 2025-05-21 to 2026-06-14 | distinct cleaned sources 203
